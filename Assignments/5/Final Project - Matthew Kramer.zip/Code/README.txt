Matthew Kramer - U20891900

Before running, make sure to execute the following:

	sudo pip install tldextract

I used this package in the feature extraction process and it is required in order to run the program.

Once that package has been installed, execute the program by running:

	python id.py

The program will request a filename. From this file, the program will extract the features, run and test each of the models, and plot the visualizations. Output is stored in text files and PNG images in the working directory.